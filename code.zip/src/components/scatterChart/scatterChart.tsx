import { useEffect, useMemo, useRef, useState } from "react";
import * as d3 from "d3";
import { TScatterChartProps, TTooltipData } from "../../types/plot.type";
import Tooltip from "../tooltip/tooltip";

type Point<T> = {
  d: T;
  i: number;
  x: number;
  y: number;
  group: string;
  color: string;
};

const MARGIN = { top: 12, right: 24, bottom: 54, left: 66 };
const HIT_RADIUS = 28; // px: how close the cursor must be to pick a point

/* -------------------------------------------------------------------------- */
/* Component                                                                  */
/* -------------------------------------------------------------------------- */

export function ScatterChart<T>({
  data,
  getX,
  getY,
  getGroup,
  getColor,
  title,
  xLabel,
  yLabel,
  legendTitle,
  height = 420,
  pointRadius = 5,
  xDomain,
  yDomain,
  domainPadding = 0.05,
  showGrid = true,
  formatX,
  formatY,
  onPointClick,
  className = "",
}: TScatterChartProps<T>) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(640);
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [legendHover, setLegendHover] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [tooltip, setTooltip] = useState<TTooltipData | null>(null);

  // Track container width so text and points stay at true pixel size.
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    setWidth(el.clientWidth);
    const ro = new ResizeObserver(([entry]) =>
      setWidth(entry.contentRect.width),
    );
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const innerW = Math.max(0, width - MARGIN.left - MARGIN.right);
  const innerH = Math.max(0, height - MARGIN.top - MARGIN.bottom);

  const { points, groups, colorOf } = useMemo(() => {
    const groupList = Array.from(new Set(data.map((d) => getGroup?.(d) ?? "")));
    const colors = new Map(
      groupList.map((g, i) => [
        g,
        getColor?.(g, i) ?? d3.schemeCategory10[i % d3.schemeCategory10.length],
      ]),
    );
    const pts: Point<T>[] = data.map((d, i) => {
      const group = getGroup?.(d) ?? "";
      return { d, i, x: getX(d), y: getY(d), group, color: colors.get(group)! };
    });
    return { points: pts, groups: groupList, colorOf: colors };
  }, [data, getX, getY, getGroup, getColor]);

  // Scales use ALL points so toggling a series never rescales the axes.
  const { xScale, yScale } = useMemo(() => {
    const padded = (ext: [number, number] | [undefined, undefined]) => {
      const [lo, hi] = ext as [number, number];
      const pad = (hi - lo || 1) * domainPadding;
      return [lo - pad, hi + pad] as [number, number];
    };
    const xd = xDomain ?? padded(d3.extent(points, (p) => p.x));
    const yd = yDomain ?? padded(d3.extent(points, (p) => p.y));
    return {
      xScale: d3.scaleLinear().domain(xd).range([0, innerW]),
      yScale: d3.scaleLinear().domain(yd).range([innerH, 0]),
    };
  }, [points, xDomain, yDomain, domainPadding, innerW, innerH]);

  const visible = useMemo(
    () => points.filter((p) => !hidden.has(p.group)),
    [points, hidden],
  );

  // Nearest-point lookup (works even when points overlap or are tiny).
  const delaunay = useMemo(
    () =>
      visible.length
        ? d3.Delaunay.from(
            visible,
            (p) => xScale(p.x),
            (p) => yScale(p.y),
          )
        : null,
    [visible, xScale, yScale],
  );

  const xTicks = xScale.ticks(Math.max(2, Math.floor(innerW / 80)));
  const yTicks = yScale.ticks(Math.max(2, Math.floor(innerH / 50)));
  const fx = formatX ?? xScale.tickFormat(xTicks.length);
  const fy = formatY ?? yScale.tickFormat(yTicks.length);

  const handleMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!delaunay) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const mx = e.clientX - rect.left - MARGIN.left;
    const my = e.clientY - rect.top - MARGIN.top;
    const idx = delaunay.find(mx, my);
    const p = visible[idx];
    if (!p || Math.hypot(xScale(p.x) - mx, yScale(p.y) - my) > HIT_RADIUS) {
      setActiveIndex(null);
      setTooltip(null);
      return;
    }
    setActiveIndex(p.i);
    setTooltip({
      x: MARGIN.left + xScale(p.x),
      y: MARGIN.top + yScale(p.y),
      date: p.group,
      values: [
        { label: xLabel ?? "x", value: fx(p.x), color: p.color },
        { label: yLabel ?? "y", value: fy(p.y), color: p.color },
      ],
    });
  };

  const clear = () => {
    setActiveIndex(null);
    setTooltip(null);
  };

  const toggleGroup = (g: string) =>
    setHidden((prev) => {
      const next = new Set(prev);
      if (next.has(g)) next.delete(g);
      else next.add(g);
      return next;
    });

  const showLegend = !!getGroup && groups.length > 0;

  return (
    <div
      className={`w-full ${className} border border-slate-200 dark:border-slate-700 rounded-lg p-4 shadow-sm dark:bg-slate-800`}
    >
      {title && (
        <h2 className="mb-3 text-2xl font-bold text-slate-900 dark:text-slate-100">
          {title}
        </h2>
      )}

      {showLegend && (
        <div className="mb-2">
          {legendTitle && (
            <div className="mb-1 text-sm text-slate-700 dark:text-slate-300">
              {legendTitle}
            </div>
          )}
          <ul className="flex flex-wrap gap-x-6 gap-y-1">
            {groups.map((g) => {
              const off = hidden.has(g);
              return (
                <li key={g}>
                  <button
                    type="button"
                    aria-pressed={!off}
                    onClick={() => toggleGroup(g)}
                    onMouseEnter={() => setLegendHover(g)}
                    onMouseLeave={() => setLegendHover(null)}
                    onFocus={() => setLegendHover(g)}
                    onBlur={() => setLegendHover(null)}
                    className={`flex items-center gap-2 rounded text-sm text-slate-900 outline-none focus-visible:ring-2 focus-visible:ring-slate-500 dark:text-slate-100 ${
                      off ? "opacity-40" : ""
                    }`}
                  >
                    <span
                      className="inline-block h-3 w-3 rounded-full"
                      style={{ backgroundColor: colorOf.get(g) }}
                    />
                    {g}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      <div ref={wrapRef} className="relative w-full">
        <svg
          width={width}
          height={height}
          role="img"
          aria-label={title ?? "Scatter plot"}
          onMouseMove={handleMove}
          onMouseLeave={clear}
          className="block"
        >
          <g transform={`translate(${MARGIN.left},${MARGIN.top})`}>
            {/* grid */}
            {showGrid && (
              <g className="stroke-slate-200 dark:stroke-slate-700">
                {xTicks.map((t) => (
                  <line
                    key={`gx${t}`}
                    x1={xScale(t)}
                    x2={xScale(t)}
                    y1={0}
                    y2={innerH}
                  />
                ))}
                {yTicks.map((t) => (
                  <line
                    key={`gy${t}`}
                    y1={yScale(t)}
                    y2={yScale(t)}
                    x1={0}
                    x2={innerW}
                  />
                ))}
              </g>
            )}

            {/* axes: left + bottom only */}
            <g className="stroke-slate-900 dark:stroke-slate-300">
              <line x1={0} x2={0} y1={0} y2={innerH} />
              <line x1={0} x2={innerW} y1={innerH} y2={innerH} />
              {xTicks.map((t) => (
                <line
                  key={`tx${t}`}
                  x1={xScale(t)}
                  x2={xScale(t)}
                  y1={innerH}
                  y2={innerH + 5}
                />
              ))}
              {yTicks.map((t) => (
                <line
                  key={`ty${t}`}
                  y1={yScale(t)}
                  y2={yScale(t)}
                  x1={-5}
                  x2={0}
                />
              ))}
            </g>

            <g className="fill-slate-900 text-xs dark:fill-slate-200">
              {xTicks.map((t) => (
                <text
                  key={`lx${t}`}
                  x={xScale(t)}
                  y={innerH + 20}
                  textAnchor="middle"
                >
                  {fx(t)}
                </text>
              ))}
              {yTicks.map((t) => (
                <text
                  key={`ly${t}`}
                  x={-10}
                  y={yScale(t)}
                  textAnchor="end"
                  dominantBaseline="middle"
                >
                  {fy(t)}
                </text>
              ))}
            </g>

            {xLabel && (
              <text
                x={innerW / 2}
                y={innerH + 44}
                textAnchor="middle"
                className="fill-slate-800 text-[13px] dark:fill-slate-200"
              >
                {xLabel}
              </text>
            )}
            {yLabel && (
              <text
                transform={`translate(${-MARGIN.left + 16},${innerH / 2}) rotate(-90)`}
                textAnchor="middle"
                className="fill-slate-800 text-[13px] dark:fill-slate-200"
              >
                {yLabel}
              </text>
            )}

            {/* points */}
            <g>
              {visible.map((p) => {
                const dimmed = legendHover !== null && legendHover !== p.group;
                const active = activeIndex === p.i;
                return (
                  <circle
                    key={p.i}
                    cx={xScale(p.x)}
                    cy={yScale(p.y)}
                    r={active ? pointRadius + 2 : pointRadius}
                    fill={p.color}
                    fillOpacity={dimmed ? 0.15 : 0.9}
                    stroke={active ? p.color : "none"}
                    strokeOpacity={0.35}
                    strokeWidth={active ? 5 : 0}
                    className={`transition-[r,fill-opacity] duration-150 ${
                      onPointClick ? "cursor-pointer" : ""
                    }`}
                    onClick={() => onPointClick?.(p.d)}
                  />
                );
              })}
            </g>
          </g>
        </svg>

        {tooltip && (
          <div
            className="pointer-events-none absolute z-10"
            style={{
              left: tooltip.x,
              top: tooltip.y,
              transform:
                tooltip.x > width * 0.6
                  ? "translate(calc(-100% - 14px), -50%)"
                  : "translate(14px, -50%)",
            }}
          >
            <Tooltip tooltip={tooltip} />
          </div>
        )}
      </div>
    </div>
  );
}
