import { useEffect, useMemo, useRef, useState, type MouseEvent } from "react";
import * as d3 from "d3";
import { TLineChartProps, TTooltipData } from "../../types/plot.type";
import Tooltip from "../tooltip/tooltip";

export default function LineChart<T>({
  data,
  getX,
  getY,
  getGroup,
  getColor,
  title,
  xLabel,
  yLabel,
  legendTitle,
  height = 420,
  yDomain,
  domainPadding = 0.1,
  curve = "linear",
  showArea,
  showPoints = true,
  showGrid = true,
  rotateXLabels = true,
  formatX = (x) => x,
  formatY,
  className = "",
}: TLineChartProps<T>) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(640);
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [legendHover, setLegendHover] = useState<string | null>(null);
  const [hoverX, setHoverX] = useState<string | null>(null);
  const [tooltip, setTooltip] = useState<TTooltipData | null>(null);

  const margin = {
    top: 12,
    right: 24,
    bottom: rotateXLabels ? 86 : 54,
    left: 66,
  };
  const innerW = Math.max(0, width - margin.left - margin.right);
  const innerH = Math.max(0, height - margin.top - margin.bottom);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    setWidth(el.clientWidth);
    const ro = new ResizeObserver(([entry]) =>
      setWidth(entry.contentRect.width),
    );
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const { xs, series } = useMemo(() => {
    const xList = Array.from(new Set(data.map(getX)));
    const order = new Map(xList.map((x, i) => [x, i]));
    const names = Array.from(new Set(data.map((d) => getGroup?.(d) ?? "")));
    return {
      xs: xList,
      series: names.map((name, i) => ({
        name,
        color:
          getColor?.(name, i) ??
          d3.schemeCategory10[i % d3.schemeCategory10.length],
        points: data
          .filter((d) => (getGroup?.(d) ?? "") === name)
          .map((d) => ({ x: getX(d), y: getY(d) }))
          .sort((a, b) => order.get(a.x)! - order.get(b.x)!),
      })),
    };
  }, [data, getX, getY, getGroup, getColor]);

  // Scales use ALL series so toggling one never rescales the axes.
  const xScale = useMemo(
    () => d3.scalePoint<string>().domain(xs).range([0, innerW]).padding(0.5),
    [xs, innerW],
  );
  const yScale = useMemo(() => {
    const [lo = 0, hi = 1] = d3.extent(
      series.flatMap((s) => s.points.map((p) => p.y)),
    );
    const pad = (hi - lo || 1) * domainPadding;
    return d3
      .scaleLinear()
      .domain(yDomain ?? [lo - pad, hi + pad])
      .range([innerH, 0]);
  }, [series, yDomain, domainPadding, innerH]);

  const xAt = (x: string) => xScale(x) ?? 0;
  const curveFn = curve === "monotone" ? d3.curveMonotoneX : d3.curveLinear;
  const line = d3
    .line<{ x: string; y: number }>()
    .x((p) => xAt(p.x))
    .y((p) => yScale(p.y))
    .curve(curveFn);
  const area = d3
    .area<{ x: string; y: number }>()
    .x((p) => xAt(p.x))
    .y0(innerH)
    .y1((p) => yScale(p.y))
    .curve(curveFn);

  const yTicks = yScale.ticks(Math.max(2, Math.floor(innerH / 50)));
  const fyTick = formatY ?? yScale.tickFormat(yTicks.length);
  const fyValue = formatY ?? d3.format(",");

  // Thin out x tick labels when they would collide.
  const step = Math.max(
    1,
    Math.ceil(
      xs.length / Math.max(1, Math.floor(innerW / (rotateXLabels ? 28 : 70))),
    ),
  );
  const xTicks = xs.filter((_, i) => i % step === 0);

  const visibleSeries = series.filter((s) => !hidden.has(s.name));
  const fillArea = showArea ?? series.length === 1;
  const showLegend = !!getGroup && series.length > 0;

  const handleMove = (e: MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const mx = e.clientX - rect.left - margin.left;
    const my = e.clientY - rect.top - margin.top;
    if (!xs.length || mx < 0 || mx > innerW || my < 0 || my > innerH) {
      setHoverX(null);
      setTooltip(null);
      return;
    }
    const nearest = xs.reduce((best, x) =>
      Math.abs(xAt(x) - mx) < Math.abs(xAt(best) - mx) ? x : best,
    );
    setHoverX(nearest);
    setTooltip({
      x: margin.left + xAt(nearest),
      y: margin.top + my,
      date: formatX(nearest),
      values: visibleSeries.flatMap((s) => {
        const p = s.points.find((pt) => pt.x === nearest);
        return p
          ? [
              {
                label: s.name || yLabel || "Value",
                value: fyValue(p.y),
                color: s.color,
              },
            ]
          : [];
      }),
    });
  };

  const clear = () => {
    setHoverX(null);
    setTooltip(null);
  };

  const toggleSeries = (name: string) =>
    setHidden((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });

  return (
    <div
      className={`w-full ${className} border border-slate-200 dark:border-slate-700 rounded-lg p-4 shadow-sm dark:bg-slate-800`}
    >
      {title && (
        <h2 className="mb-3 text-2xl font-bold text-slate-900 dark:text-slate-100">
          {title}
        </h2>
      )}

      {showLegend && (
        <div className="mb-2">
          {legendTitle && (
            <div className="mb-1 text-sm text-slate-700 dark:text-slate-300">
              {legendTitle}
            </div>
          )}
          <ul className="flex flex-wrap gap-x-6 gap-y-1">
            {series.map((s) => (
              <li key={s.name}>
                <button
                  type="button"
                  aria-pressed={!hidden.has(s.name)}
                  onClick={() => toggleSeries(s.name)}
                  onMouseEnter={() => setLegendHover(s.name)}
                  onMouseLeave={() => setLegendHover(null)}
                  onFocus={() => setLegendHover(s.name)}
                  onBlur={() => setLegendHover(null)}
                  className={`flex items-center gap-2 rounded text-sm text-slate-900 outline-none focus-visible:ring-2 focus-visible:ring-slate-500 dark:text-slate-100 ${
                    hidden.has(s.name) ? "opacity-40" : ""
                  }`}
                >
                  <span
                    className="inline-block h-1 w-4 rounded-full"
                    style={{ backgroundColor: s.color }}
                  />
                  {s.name}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div ref={wrapRef} className="relative w-full">
        <svg
          width={width}
          height={height}
          role="img"
          aria-label={title ?? "Line chart"}
          onMouseMove={handleMove}
          onMouseLeave={clear}
          className="block"
        >
          <g transform={`translate(${margin.left},${margin.top})`}>
            {showGrid && (
              <g className="stroke-slate-200 dark:stroke-slate-700">
                {xTicks.map((x) => (
                  <line
                    key={`gx${x}`}
                    x1={xAt(x)}
                    x2={xAt(x)}
                    y1={0}
                    y2={innerH}
                  />
                ))}
                {yTicks.map((t) => (
                  <line
                    key={`gy${t}`}
                    x1={0}
                    x2={innerW}
                    y1={yScale(t)}
                    y2={yScale(t)}
                  />
                ))}
              </g>
            )}

            {/* areas + lines */}
            {visibleSeries.map((s) => {
              const dimmed = legendHover !== null && legendHover !== s.name;
              return (
                <g
                  key={s.name}
                  className={`transition-opacity duration-150 ${dimmed ? "opacity-20" : "opacity-100"}`}
                >
                  {fillArea && (
                    <path
                      d={area(s.points) ?? undefined}
                      fill={s.color}
                      fillOpacity={0.12}
                    />
                  )}
                  <path
                    d={line(s.points) ?? undefined}
                    fill="none"
                    stroke={s.color}
                    strokeWidth={3}
                    strokeLinejoin="round"
                    strokeLinecap="round"
                  />
                  {showPoints &&
                    s.points.map((p) => (
                      <circle
                        key={p.x}
                        cx={xAt(p.x)}
                        cy={yScale(p.y)}
                        r={hoverX === p.x ? 6 : 4}
                        fill={s.color}
                        className="transition-[r] duration-100"
                      />
                    ))}
                </g>
              );
            })}

            {/* hover guide */}
            {hoverX !== null && (
              <line
                x1={xAt(hoverX)}
                x2={xAt(hoverX)}
                y1={0}
                y2={innerH}
                strokeDasharray="4 4"
                className="pointer-events-none stroke-slate-400"
              />
            )}

            {/* axes: left + bottom only */}
            <g className="stroke-slate-900 dark:stroke-slate-300">
              <line x1={0} x2={0} y1={0} y2={innerH} />
              <line x1={0} x2={innerW} y1={innerH} y2={innerH} />
              {xTicks.map((x) => (
                <line
                  key={`tx${x}`}
                  x1={xAt(x)}
                  x2={xAt(x)}
                  y1={innerH}
                  y2={innerH + 5}
                />
              ))}
              {yTicks.map((t) => (
                <line
                  key={`ty${t}`}
                  x1={-5}
                  x2={0}
                  y1={yScale(t)}
                  y2={yScale(t)}
                />
              ))}
            </g>

            <g className="fill-slate-900 text-xs dark:fill-slate-200">
              {xTicks.map((x) =>
                rotateXLabels ? (
                  <text
                    key={`lx${x}`}
                    x={xAt(x)}
                    y={innerH + 16}
                    textAnchor="end"
                    transform={`rotate(-35 ${xAt(x)} ${innerH + 16})`}
                  >
                    {formatX(x)}
                  </text>
                ) : (
                  <text
                    key={`lx${x}`}
                    x={xAt(x)}
                    y={innerH + 20}
                    textAnchor="middle"
                  >
                    {formatX(x)}
                  </text>
                ),
              )}
              {yTicks.map((t) => (
                <text
                  key={`ly${t}`}
                  x={-10}
                  y={yScale(t)}
                  textAnchor="end"
                  dominantBaseline="middle"
                >
                  {fyTick(t)}
                </text>
              ))}
            </g>

            {xLabel && (
              <text
                x={innerW / 2}
                y={innerH + (rotateXLabels ? 72 : 44)}
                textAnchor="middle"
                className="fill-slate-800 text-[13px] dark:fill-slate-200"
              >
                {xLabel}
              </text>
            )}
            {yLabel && (
              <text
                transform={`translate(${-margin.left + 16},${innerH / 2}) rotate(-90)`}
                textAnchor="middle"
                className="fill-slate-800 text-[13px] dark:fill-slate-200"
              >
                {yLabel}
              </text>
            )}
          </g>
        </svg>

        {tooltip && tooltip.values.length > 0 && (
          <div
            className="pointer-events-none absolute z-10"
            style={{
              left: tooltip.x,
              top: tooltip.y,
              transform:
                tooltip.x > width * 0.6
                  ? "translate(calc(-100% - 14px), -50%)"
                  : "translate(14px, -50%)",
            }}
          >
            <Tooltip tooltip={tooltip} />
          </div>
        )}
      </div>
    </div>
  );
}
