import { useEffect, useMemo, useRef, useState } from "react";
import * as d3 from "d3";
import { TBarChartProps, TTooltipData } from "../../types/plot.type";
import Tooltip from "../tooltip/tooltip";

export default function BarChart<T>({
  data,
  getX,
  getY,
  getColor,
  title,
  xLabel,
  yLabel,
  height = 420,
  barPadding = 0.15,
  showValues = true,
  showGrid = true,
  rotateXLabels = true,
  yDomain,
  formatY,
  onBarClick,
  className = "",
}: TBarChartProps<T>) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(640);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [tooltip, setTooltip] = useState<TTooltipData | null>(null);

  const margin = {
    top: 20,
    right: 24,
    bottom: rotateXLabels ? 86 : 54,
    left: 66,
  };
  const innerW = Math.max(0, width - margin.left - margin.right);
  const innerH = Math.max(0, height - margin.top - margin.bottom);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    setWidth(el.clientWidth);
    const ro = new ResizeObserver(([entry]) =>
      setWidth(entry.contentRect.width),
    );
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const bars = useMemo(
    () =>
      data.map((d, i) => ({
        d,
        i,
        x: getX(d),
        y: getY(d),
        color:
          getColor?.(d, i) ??
          d3.schemeCategory10[i % d3.schemeCategory10.length],
      })),
    [data, getX, getY, getColor],
  );

  const xScale = useMemo(
    () =>
      d3
        .scaleBand<string>()
        .domain(bars.map((b) => b.x))
        .range([0, innerW])
        .padding(barPadding),
    [bars, innerW, barPadding],
  );

  const yScale = useMemo(() => {
    const [lo = 0, hi = 0] = d3.extent(bars, (b) => b.y);
    return d3
      .scaleLinear()
      .domain(yDomain ?? [Math.min(0, lo), Math.max(0, hi) || 1])
      .nice()
      .range([innerH, 0]);
  }, [bars, yDomain, innerH]);

  const zero = yScale(0);
  const yTicks = yScale.ticks(Math.max(2, Math.floor(innerH / 50)));
  const fyTick = formatY ?? yScale.tickFormat(yTicks.length);
  const fyValue = formatY ?? d3.format(",");

  const step = Math.max(
    1,
    Math.ceil(
      bars.length / Math.max(1, Math.floor(innerW / (rotateXLabels ? 24 : 60))),
    ),
  );
  const labelled = bars.filter((_, i) => i % step === 0);
  const center = (x: string) => (xScale(x) ?? 0) + xScale.bandwidth() / 2;

  const showTip = (b: (typeof bars)[number]) => {
    setActiveIndex(b.i);
    setTooltip({
      x: margin.left + center(b.x),
      y: margin.top + Math.min(yScale(b.y), zero),
      date: b.x,
      values: [
        { label: yLabel ?? "Value", value: fyValue(b.y), color: b.color },
      ],
    });
  };

  const clear = () => {
    setActiveIndex(null);
    setTooltip(null);
  };

  return (
    <div
      className={`w-full ${className} border border-slate-200 dark:border-slate-700 rounded-lg p-4 shadow-sm dark:bg-slate-800`}
    >
      {title && (
        <h2 className="mb-3 text-2xl font-bold text-slate-900 dark:text-slate-100">
          {title}
        </h2>
      )}

      <div ref={wrapRef} className="relative w-full">
        <svg
          width={width}
          height={height}
          role="img"
          aria-label={title ?? "Bar chart"}
          className="block"
        >
          <g transform={`translate(${margin.left},${margin.top})`}>
            {showGrid && (
              <g className="stroke-slate-200 dark:stroke-slate-700">
                {labelled.map((b) => (
                  <line
                    key={`gx${b.i}`}
                    x1={center(b.x)}
                    x2={center(b.x)}
                    y1={0}
                    y2={innerH}
                  />
                ))}
                {yTicks.map((t) => (
                  <line
                    key={`gy${t}`}
                    x1={0}
                    x2={innerW}
                    y1={yScale(t)}
                    y2={yScale(t)}
                  />
                ))}
              </g>
            )}

            {/* bars */}
            {bars.map((b) => {
              const top = Math.min(yScale(b.y), zero);
              const h = Math.abs(zero - yScale(b.y));
              const dimmed = activeIndex !== null && activeIndex !== b.i;
              return (
                <g
                  key={b.i}
                  className={`transition-opacity duration-150 ${dimmed ? "opacity-60" : "opacity-100"}`}
                >
                  <rect
                    x={xScale(b.x)}
                    y={top}
                    width={xScale.bandwidth()}
                    height={h}
                    fill={b.color}
                    className={onBarClick ? "cursor-pointer" : ""}
                    onMouseEnter={() => showTip(b)}
                    onMouseMove={() => showTip(b)}
                    onMouseLeave={clear}
                    onClick={() => onBarClick?.(b.d)}
                  />
                  {showValues && (
                    <text
                      x={center(b.x)}
                      y={b.y >= 0 ? top - 6 : top + h + 14}
                      textAnchor="middle"
                      className="pointer-events-none fill-slate-900 text-[11px] dark:fill-slate-200"
                    >
                      {fyValue(b.y)}
                    </text>
                  )}
                </g>
              );
            })}

            {/* axes: left + bottom only */}
            <g className="stroke-slate-900 dark:stroke-slate-300">
              <line x1={0} x2={0} y1={0} y2={innerH} />
              <line x1={0} x2={innerW} y1={innerH} y2={innerH} />
              {labelled.map((b) => (
                <line
                  key={`tx${b.i}`}
                  x1={center(b.x)}
                  x2={center(b.x)}
                  y1={innerH}
                  y2={innerH + 5}
                />
              ))}
              {yTicks.map((t) => (
                <line
                  key={`ty${t}`}
                  x1={-5}
                  x2={0}
                  y1={yScale(t)}
                  y2={yScale(t)}
                />
              ))}
            </g>

            <g className="fill-slate-900 text-xs dark:fill-slate-200">
              {labelled.map((b) =>
                rotateXLabels ? (
                  <text
                    key={`lx${b.i}`}
                    x={center(b.x)}
                    y={innerH + 16}
                    textAnchor="end"
                    transform={`rotate(-35 ${center(b.x)} ${innerH + 16})`}
                  >
                    {b.x}
                  </text>
                ) : (
                  <text
                    key={`lx${b.i}`}
                    x={center(b.x)}
                    y={innerH + 20}
                    textAnchor="middle"
                  >
                    {b.x}
                  </text>
                ),
              )}
              {yTicks.map((t) => (
                <text
                  key={`ly${t}`}
                  x={-10}
                  y={yScale(t)}
                  textAnchor="end"
                  dominantBaseline="middle"
                >
                  {fyTick(t)}
                </text>
              ))}
            </g>

            {xLabel && (
              <text
                x={innerW / 2}
                y={innerH + (rotateXLabels ? 72 : 44)}
                textAnchor="middle"
                className="fill-slate-800 text-[13px] dark:fill-slate-200"
              >
                {xLabel}
              </text>
            )}
            {yLabel && (
              <text
                transform={`translate(${-margin.left + 16},${innerH / 2}) rotate(-90)`}
                textAnchor="middle"
                className="fill-slate-800 text-[13px] dark:fill-slate-200"
              >
                {yLabel}
              </text>
            )}
          </g>
        </svg>

        {tooltip && (
          <div
            className="pointer-events-none absolute z-10"
            style={{
              left: tooltip.x,
              top: tooltip.y,
              transform:
                tooltip.x > width * 0.6
                  ? "translate(calc(-100% - 14px), -110%)"
                  : "translate(14px, -110%)",
            }}
          >
            <Tooltip tooltip={tooltip} />
          </div>
        )}
      </div>
    </div>
  );
}
