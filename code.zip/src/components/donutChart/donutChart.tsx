import { useMemo, useRef, useState } from "react";
import * as d3 from "d3";
import { TTooltipData, TDonutChartProps } from "../../types/plot.type";
import { DEFAULT_DONUT_COLORS } from "../../constants";
import Tooltip from "../tooltip/tooltip";

const VIEWBOX = 560;

export function DonutChart<T>({
  data,
  getLabel,
  getValue,
  getColor,
  title,
  centerLabel,
  innerRadiusRatio = 0.6,
  padAngle = 0.004,
  cornerRadius = 0,
  labelMargin = 100,
  minPercentToLabel = 0.03,
  showLabels = true,
  showPercentages = true,
  formatPercent = d3.format(".0%"),
  className = "",
}: TDonutChartProps<T>) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [tooltip, setTooltip] = useState<TTooltipData | null>(null);
  const [containerWidth, setContainerWidth] = useState(0);

  const outerRadius = VIEWBOX / 2 - labelMargin;
  const innerRadius = outerRadius * innerRadiusRatio;
  const center = VIEWBOX / 2;

  const total = useMemo(
    () => d3.sum(data, (d) => Math.max(0, getValue(d))),
    [data, getValue],
  );

  const slices = useMemo(() => {
    const pie = d3
      .pie<T>()
      .value((d) => Math.max(0, getValue(d)))
      .sort(null) // keep input order, starting at 12 o'clock, clockwise
      .padAngle(padAngle);
    return pie(data).map((arc, i) => ({
      arc,
      color:
        getColor?.(arc.data, i) ??
        DEFAULT_DONUT_COLORS[i % DEFAULT_DONUT_COLORS.length],
    }));
  }, [data, getValue, getColor, padAngle]);

  const arcPath = useMemo(
    () =>
      d3
        .arc<d3.PieArcDatum<T>>()
        .innerRadius(innerRadius)
        .outerRadius(outerRadius)
        .cornerRadius(cornerRadius),
    [innerRadius, outerRadius, cornerRadius],
  );

  // Anchor point for the % text: middle of the ring thickness.
  const percentArc = useMemo(
    () =>
      d3
        .arc<d3.PieArcDatum<T>>()
        .innerRadius((innerRadius + outerRadius) / 2)
        .outerRadius((innerRadius + outerRadius) / 2),
    [innerRadius, outerRadius],
  );

  // Anchor point for the outside label.
  const labelArc = useMemo(
    () =>
      d3
        .arc<d3.PieArcDatum<T>>()
        .innerRadius(outerRadius + 16)
        .outerRadius(outerRadius + 16),
    [outerRadius],
  );

  const showTooltip = (event: React.MouseEvent, index: number) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setContainerWidth(rect.width);
    const { arc, color } = slices[index];
    const value = getValue(arc.data);
    const share = total > 0 ? value / total : 0;
    setActiveIndex(index);
    setTooltip({
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
      date: getLabel(arc.data),
      values: [
        {
          label: getLabel(arc.data),
          value: `${formatPercent(share)}`,
          color,
        },
      ],
    });
  };

  const hideTooltip = () => {
    setActiveIndex(null);
    setTooltip(null);
  };

  return (
    <div
      className={`w-full ${className} border border-slate-200 dark:border-slate-700 rounded-lg p-4 shadow-sm dark:bg-slate-800`}
    >
      {title && (
        <h2 className="mb-2 text-2xl font-bold text-slate-900 dark:text-slate-100">
          {title}
        </h2>
      )}

      <div ref={containerRef} className="relative mx-auto w-full max-w-xl">
        <svg
          viewBox={`0 0 ${VIEWBOX} ${VIEWBOX}`}
          className="h-auto w-full"
          role="img"
          aria-label={title ?? "Donut chart"}
        >
          <g transform={`translate(${center},${center})`}>
            {slices.map(({ arc, color }, i) => {
              const value = getValue(arc.data);
              const share = total > 0 ? value / total : 0;
              const [px, py] = percentArc.centroid(arc);
              const [lx, ly] = labelArc.centroid(arc);
              const mid = (arc.startAngle + arc.endAngle) / 2;
              const anchor = mid < Math.PI ? "start" : "end";
              const dimmed = activeIndex !== null && activeIndex !== i;

              return (
                <g
                  key={`${getLabel(arc.data)}-${i}`}
                  className={`transition-opacity duration-150 ${
                    dimmed ? "opacity-40" : "opacity-100"
                  }`}
                >
                  <path
                    d={arcPath(arc) ?? undefined}
                    fill={color}
                    stroke="white"
                    strokeWidth={2}
                    className="cursor-pointer outline-none dark:stroke-slate-900"
                    tabIndex={0}
                    aria-label={`${getLabel(arc.data)}: ${formatPercent(share)}`}
                    onMouseEnter={(e) => showTooltip(e, i)}
                    onMouseMove={(e) => showTooltip(e, i)}
                    onMouseLeave={hideTooltip}
                    onFocus={() => setActiveIndex(i)}
                    onBlur={hideTooltip}
                  />

                  {showPercentages && share >= minPercentToLabel && (
                    <text
                      x={px}
                      y={py}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      className="pointer-events-none fill-slate-900 text-[17px]"
                    >
                      {formatPercent(share)}
                    </text>
                  )}

                  {showLabels && (
                    <text
                      x={lx}
                      y={ly}
                      textAnchor={anchor}
                      dominantBaseline="middle"
                      className="pointer-events-none fill-slate-800 text-[18px] dark:fill-slate-200"
                    >
                      {getLabel(arc.data)}
                    </text>
                  )}
                </g>
              );
            })}

            {centerLabel && (
              <text
                textAnchor="middle"
                dominantBaseline="middle"
                className="pointer-events-none fill-slate-900 text-[28px] font-bold dark:fill-slate-100"
              >
                {centerLabel}
              </text>
            )}
          </g>
        </svg>

        {tooltip && (
          <div
            className="pointer-events-none absolute z-10"
            style={{
              left: tooltip.x,
              top: tooltip.y,
              // flip to the left of the cursor near the right edge
              transform:
                tooltip.x > containerWidth * 0.6
                  ? "translate(calc(-100% - 12px), 12px)"
                  : "translate(12px, 12px)",
            }}
          >
            <Tooltip tooltip={tooltip} />
          </div>
        )}
      </div>
    </div>
  );
}
