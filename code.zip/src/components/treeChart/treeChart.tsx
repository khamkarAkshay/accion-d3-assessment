import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type MouseEvent,
} from "react";
import * as d3 from "d3";
import {
  TTreeNodeContext,
  TTreeChartProps,
  TTooltipData,
} from "../../types/plot.type";
import Tooltip from "../tooltip/tooltip";

/* -------------------------------------------------------------------------- */
/* Types                                                                      */
/* -------------------------------------------------------------------------- */

type Pos = { x: number; y: number };

type Internal<T> = {
  id: string;
  data: T;
  index: number;
  children?: Internal<T>[];
};

type LayoutNode<T> = Pos & {
  id: string;
  data: T;
  ctx: TTreeNodeContext;
  parentId?: string;
  color: string;
  hasChildren: boolean;
  isCollapsed: boolean;
};

/* -------------------------------------------------------------------------- */
/* Animation: tween every node from its previous position to its new one      */
/* -------------------------------------------------------------------------- */

function useAnimatedPositions(
  targets: Map<string, Pos>,
  parentOf: Map<string, string | undefined>,
  duration: number,
) {
  const [current, setCurrent] = useState(targets);
  const currentRef = useRef(targets);

  useEffect(() => {
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduce || duration <= 0) {
      currentRef.current = targets;
      setCurrent(targets);
      return;
    }

    // New nodes start from their nearest already-visible ancestor.
    const from = new Map<string, Pos>();
    targets.forEach((t, id) => {
      let p = currentRef.current.get(id);
      let pid = parentOf.get(id);
      while (!p && pid) {
        p = currentRef.current.get(pid);
        pid = parentOf.get(pid);
      }
      from.set(id, p ?? t);
    });

    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const k = Math.min(1, (now - start) / duration);
      const e = d3.easeCubicInOut(k);
      const next = new Map<string, Pos>();
      targets.forEach((t, id) => {
        const f = from.get(id)!;
        next.set(id, { x: f.x + (t.x - f.x) * e, y: f.y + (t.y - f.y) * e });
      });
      currentRef.current = next;
      setCurrent(next);
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targets, duration]);

  return current;
}

/* -------------------------------------------------------------------------- */
/* Component                                                                  */
/* -------------------------------------------------------------------------- */

const MARGIN = { top: 24, right: 16, bottom: 24, left: 40 };

export function TreeChart<T>({
  data,
  getChildren,
  getLabel,
  getColor,
  title,
  defaultExpandedDepth = Infinity,
  showControls = true,
  columnWidth = 300,
  rowHeight = 44,
  groupGap = 2.5,
  labelSpace = 190,
  rootRadius = 9,
  nodeRadius = 7,
  linkShape = "straight",
  animationMs = 300,
  onNodeClick,
  className = "",
}: TTreeChartProps<T>) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [tooltip, setTooltip] = useState<TTooltipData | null>(null);
  const [containerWidth, setContainerWidth] = useState(0);

  // Full tree with stable path ids and depth-first indices.
  const tree = useMemo(() => {
    let counter = 0;
    const build = (d: T, id: string): Internal<T> => {
      const index = counter++;
      const kids = getChildren(d);
      return {
        id,
        data: d,
        index,
        children: kids?.length
          ? kids.map((c, i) => build(c, `${id}.${i}`))
          : undefined,
      };
    };
    return build(data, "0");
  }, [data, getChildren]);

  const fullDepth = useMemo(() => {
    const walk = (n: Internal<T>): number =>
      n.children ? 1 + Math.max(...n.children.map(walk)) : 0;
    return walk(tree);
  }, [tree]);

  const [collapsed, setCollapsed] = useState<Set<string>>(() => {
    const s = new Set<string>();
    const walk = (n: Internal<T>, depth: number) => {
      if (!n.children) return;
      if (depth >= defaultExpandedDepth) s.add(n.id);
      n.children.forEach((c) => walk(c, depth + 1));
    };
    walk(tree, 0);
    return s;
  });

  const toggle = (id: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const expandAll = () => setCollapsed(new Set());
  const collapseAll = () => {
    const s = new Set<string>();
    const walk = (n: Internal<T>) => {
      if (n.children && n.id !== tree.id) s.add(n.id);
      n.children?.forEach(walk);
    };
    walk(tree);
    setCollapsed(s);
  };

  // d3.tree layout for the currently visible nodes.
  const { nodes, width, height } = useMemo(() => {
    const root = d3.hierarchy<Internal<T>>(tree, (n) =>
      collapsed.has(n.id) ? undefined : n.children,
    );
    d3
      .tree<Internal<T>>()
      .nodeSize([rowHeight, columnWidth])
      .separation((a, b) => (a.parent === b.parent ? 1 : groupGap))(root);

    const all = root.descendants();
    const minX = d3.min(all, (n) => n.x ?? 0) ?? 0;
    const maxX = d3.max(all, (n) => n.x ?? 0) ?? 0;

    const laid: LayoutNode<T>[] = all.map((n) => {
      const path = n
        .ancestors()
        .reverse()
        .map((a) => getLabel(a.data.data));
      const childCount = n.data.children?.length ?? 0;
      const ctx: TTreeNodeContext = {
        id: n.data.id,
        depth: n.depth,
        index: n.data.index,
        path,
        childCount,
      };
      return {
        id: n.data.id,
        data: n.data.data,
        ctx,
        parentId: n.parent?.data.id,
        x: MARGIN.left + (n.y ?? 0),
        y: MARGIN.top + ((n.x ?? 0) - minX),
        color:
          getColor?.(n.data.data, ctx) ??
          d3.schemeCategory10[n.data.index % d3.schemeCategory10.length],
        hasChildren: childCount > 0,
        isCollapsed: collapsed.has(n.data.id),
      };
    });

    return {
      nodes: laid,
      width: MARGIN.left + fullDepth * columnWidth + labelSpace + MARGIN.right,
      height: MARGIN.top + (maxX - minX) + MARGIN.bottom,
    };
  }, [
    tree,
    collapsed,
    rowHeight,
    columnWidth,
    groupGap,
    labelSpace,
    fullDepth,
    getLabel,
    getColor,
  ]);

  const targets = useMemo(
    () => new Map(nodes.map((n) => [n.id, { x: n.x, y: n.y }])),
    [nodes],
  );
  const parentOf = useMemo(
    () => new Map(nodes.map((n) => [n.id, n.parentId])),
    [nodes],
  );
  const positions = useAnimatedPositions(targets, parentOf, animationMs);
  const posOf = (id: string): Pos => positions.get(id) ?? targets.get(id)!;

  const curve = useMemo(
    () =>
      d3
        .linkHorizontal<{ source: Pos; target: Pos }, Pos>()
        .x((d) => d.x)
        .y((d) => d.y),
    [],
  );

  const showTip = (e: MouseEvent, n: LayoutNode<T>) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setContainerWidth(rect.width);
    const values = [
      { label: "Path", value: n.ctx.path.join(" › "), color: n.color },
      ...(n.ctx.childCount > 0
        ? [{ label: "Children", value: n.ctx.childCount, color: n.color }]
        : []),
    ];
    setTooltip({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      date: getLabel(n.data),
      values,
    });
  };

  const onKey = (e: KeyboardEvent, n: LayoutNode<T>) => {
    if (!n.hasChildren) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      toggle(n.id);
      onNodeClick?.(n.data, n.ctx);
    }
  };

  return (
    <div
      className={`w-full ${className} border border-slate-200 dark:border-slate-700 rounded-lg p-4 shadow-sm dark:bg-slate-800`}
    >
      {(title || showControls) && (
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          {title && (
            <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              {title}
            </h2>
          )}
          {showControls && (
            <div className="flex gap-2 text-sm">
              <button
                type="button"
                onClick={expandAll}
                className="rounded-md border border-slate-300 px-2.5 py-1 text-slate-700 hover:bg-slate-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-500 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Expand all
              </button>
              <button
                type="button"
                onClick={collapseAll}
                className="rounded-md border border-slate-300 px-2.5 py-1 text-slate-700 hover:bg-slate-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-500 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Collapse all
              </button>
            </div>
          )}
        </div>
      )}

      <div ref={containerRef} className="relative w-full overflow-x-auto">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="h-auto w-full min-w-[640px]"
          role="tree"
          aria-label={title ?? "Tree chart"}
        >
          {/* links */}
          <g fill="none" strokeWidth={1.75} strokeLinecap="round">
            {nodes
              .filter((n) => n.parentId)
              .map((n) => {
                const s = posOf(n.parentId!);
                const t = posOf(n.id);
                return (
                  <path
                    key={`link-${n.id}`}
                    d={
                      linkShape === "curve"
                        ? (curve({ source: s, target: t }) ?? undefined)
                        : `M${s.x},${s.y}L${t.x},${t.y}`
                    }
                    stroke={n.color}
                    strokeOpacity={0.5}
                  />
                );
              })}
          </g>

          {/* nodes */}
          {nodes.map((n) => {
            const p = posOf(n.id);
            const r = n.ctx.depth === 0 ? rootRadius : nodeRadius;
            return (
              <g
                key={n.id}
                transform={`translate(${p.x},${p.y})`}
                role="treeitem"
                aria-expanded={n.hasChildren ? !n.isCollapsed : undefined}
                aria-label={getLabel(n.data)}
                tabIndex={n.hasChildren ? 0 : -1}
                className={`outline-none ${
                  n.hasChildren ? "cursor-pointer" : "cursor-default"
                } [&:focus-visible>circle:first-child]:stroke-slate-900 dark:[&:focus-visible>circle:first-child]:stroke-white`}
                onClick={() => {
                  if (n.hasChildren) toggle(n.id);
                  onNodeClick?.(n.data, n.ctx);
                }}
                onKeyDown={(e) => onKey(e, n)}
                onMouseEnter={(e) => showTip(e, n)}
                onMouseMove={(e) => showTip(e, n)}
                onMouseLeave={() => setTooltip(null)}
              >
                {/* collapsed halo = "there is more in here" */}
                {n.isCollapsed && (
                  <circle
                    r={r + 4}
                    fill="none"
                    stroke={n.color}
                    strokeWidth={1.5}
                    strokeOpacity={0.55}
                  />
                )}
                <circle
                  r={r}
                  fill={n.color}
                  stroke="transparent"
                  strokeWidth={2}
                />
                <text
                  x={r + 8}
                  dominantBaseline="middle"
                  className={`pointer-events-none fill-slate-900 stroke-white text-[15px] dark:fill-slate-100 dark:stroke-slate-900 ${
                    n.ctx.depth === 0 ? "font-bold" : ""
                  }`}
                  // white halo so connecting lines never run through the text
                  style={{
                    paintOrder: "stroke",
                    strokeWidth: 4,
                    strokeLinejoin: "round",
                  }}
                >
                  {getLabel(n.data)}
                  {n.isCollapsed && (
                    <tspan
                      dx={6}
                      className="fill-slate-500 dark:fill-slate-400"
                      style={{ strokeWidth: 4 }}
                    >
                      ({n.ctx.childCount})
                    </tspan>
                  )}
                </text>
              </g>
            );
          })}
        </svg>

        {tooltip && (
          <div
            className="pointer-events-none absolute z-10"
            style={{
              left: tooltip.x,
              top: tooltip.y,
              transform:
                tooltip.x > containerWidth * 0.6
                  ? "translate(calc(-100% - 12px), 12px)"
                  : "translate(12px, 12px)",
            }}
          >
            <Tooltip tooltip={tooltip} />
          </div>
        )}
      </div>
    </div>
  );
}
